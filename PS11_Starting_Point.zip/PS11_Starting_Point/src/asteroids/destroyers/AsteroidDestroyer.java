package asteroids.destroyers;

/**
 * Used to mark Participants that destroy Asteroids.
 */
public interface AsteroidDestroyer
{
}
