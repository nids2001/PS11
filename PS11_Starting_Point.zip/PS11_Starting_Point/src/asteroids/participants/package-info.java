/**
 * All of the classes in this package extend the abstract {@link asteroids.game.Participant} class
 * to define a new kind of participant in the game.
 */
package asteroids.participants;